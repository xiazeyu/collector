# collector
Collect files and rename it using python

extremely lightweight. no js, each HTML files < 2KB.